package com.example.interviewapp;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toolbar;

public class SelectOptions extends AppCompatActivity {
    Button b1,b2,b3;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_options);
        //tool = findViewById(R.id.tool);
        textView = findViewById(R.id.textView);
        b1=findViewById(R.id.basic);
        b2=findViewById(R.id.intermediate);
        b3=findViewById(R.id.advance);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(SelectOptions.this,Qustions.class);
                startActivity(intent);
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(SelectOptions.this,Qustions.class);
                startActivity(intent);
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(SelectOptions.this,Qustions.class);
                startActivity(intent);
            }
        });
    }
}
