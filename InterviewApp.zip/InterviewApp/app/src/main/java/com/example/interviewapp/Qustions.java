package com.example.interviewapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Qustions extends AppCompatActivity {
    final String[] javaarray = {"what is java ?",
            "How does Java enable high performance?",
            "What are the Java IDE’s?",
            " What do you mean by Constructor?",
            "What is a Class?",
            " What is an Object?",
            "What are the Oops concepts?",
            "What is Inheritance?",
            "What is Encapsulation?",
            "What is Polymorphism?"};
    final String[] javaanwser = {"Java is a high-level programming language and is platform independent.\n" +
            "\n" +
            "Java is a collection of objects. It was developed by Sun Microsystems. There are a lot of applications, websites and Games that are developed using Java."
            , "Java uses Just In Time compiler to enable high performance. JIT is used to convert the instructions into bytecodes."
            , "Eclipse and NetBeans are the IDE's of JAVA"
            , "When a new object is created in a program a constructor gets invoked corresponding to the class.\n" +
            "The constructor is a method which has the same name as class name.\n" +
            "If a user doesn’t create a constructor implicitly a default constructor will be created.\n" +
            "The constructor can be overloaded."
            , "All Java codes are defined in a class. A Class has variables and methods.\n" +
            "\n" +
            "Variables are attributes which define the state of a class.\n" +
            "\n" +
            "Methods are the place where the exact business logic has to be done. It contains a set of statements (or) instructions to satisfy the particular requirement."
            , "An instance of a class is called object. The object has state and behavior.\n" +
            "\n" +
            "Whenever the JVM reads the “new()” keyword then it will create an instance of that class."
            , "Inheritance\n" +
            "Encapsulation\n" +
            "Polymorphism\n" +
            "Abstraction\n" +
            "Interface"
            , "Inheritance means one class can extend to another class. So that the codes can be reused from one class to another class.\n" +
            "\n" +
            "Existing class is known as Super class whereas the derived class is known as a sub class."
            , "Protects the code from others.\n" +
            "Code maintainability."
            , "Polymorphism means many forms.\n" +
            "\n" +
            "A single object can refer the super class or sub-class depending on the reference type which is called polymorphism."
    };

    ImageView imageViewAnswer, nextPageImage,main;
    TextView textViewAnswer, qustion, counter,tittle;
    int count = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qustions);
        imageViewAnswer = findViewById(R.id.show);
        textViewAnswer = findViewById(R.id.textViewAnswer);
        qustion = findViewById(R.id.question);
        nextPageImage = findViewById(R.id.nextQustionImage);
        counter = findViewById(R.id.counter);
tittle=findViewById(R.id.title);
        textViewAnswer.setVisibility(View.INVISIBLE);
        qustion.setText(javaarray[count]);
        tittle.setText("Q no"+count);
        textViewAnswer.setText(javaanwser[count]);
        counter.setText(count + "/" + javaarray.length);
        main=findViewById(R.id.main);
        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Qustions.this,SelectOptions.class);
                startActivity(intent);
            }
        });

//
//        nextPageImage.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                count++;
//                //textViewAnswer.setVisibility(View.INVISIBLE);
//                qustion.setText(javaarray[count]);
//                //.setText("Q no"+ques);
//                textViewAnswer.setText(javaanwser[count]);
//                counter.setText(count + "/" + javaarray.length);
//
//
//            }
//        });
//        imageViewAnswer.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(Qustions.this, "show", Toast.LENGTH_SHORT).show();
//                textViewAnswer.setVisibility(View.VISIBLE);
//            }
//        });


    }


    public void Browser(View view) {
        switch (view.getId())
        {
            case R.id.back:
                if (count!=0) {
                    count--;
                    textViewAnswer.setVisibility(View.INVISIBLE);
                    qustion.setText(javaarray[count]);
                    tittle.setText("Q no" + count);
                    textViewAnswer.setText(javaanwser[count]);
                    counter.setText(count + "/" + javaarray.length);

                    break;
                }else
                {
                    Toast.makeText(this, "Cant Back", Toast.LENGTH_SHORT).show();
                }
            case R.id.show:
                textViewAnswer.setVisibility(View.VISIBLE);


                break;
            case R.id.nextQustionImage:

                count++;
                if (count<javaarray.length) {
                    textViewAnswer.setVisibility(View.INVISIBLE);
                    qustion.setText(javaarray[count]);
                    tittle.setText("Q No " + count);
                    textViewAnswer.setText(javaanwser[count]);
                    counter.setText(count + "/" + javaarray.length);
                    break;
                }else {
                    Toast.makeText(this, "Thnaks its End", Toast.LENGTH_SHORT).show();
                }
        }

    }
}